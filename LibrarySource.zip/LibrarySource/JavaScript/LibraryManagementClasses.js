
class Book {
    constructor(name, author, type) {
        this.name = name;
        this.author = author;
        this.type = type;
      }
      addToLocalStorage(book) {
        let bookArray;
        let bookList = localStorage.getItem("bookList");
      
        if (bookList == null) {
          bookArray = [];
        } else {
          bookArray = JSON.parse(bookList);
        }
      
        bookArray.push(book);
      
        localStorage.setItem("bookList", JSON.stringify(bookArray));
      }
      clearFormFields() {
        let addBook = document.getElementById("addBook");
        addBook.reset();
      }
}

class Display {

    showAlert(status, message) {
        let info;
        if (status == "success") {
          info = "Success";
        } else if(status == "danger") {
          info = "Error";
        }
      
        let uiString = `<div class="alert alert-${status} alert-dismissible fade show" role="alert">
          <strong>${info} </strong> ${message}
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>`;
      
        let alert = document.getElementById("showAlert");
        alert.innerHTML = uiString;
      
        setTimeout(() => {
          alert.innerHTML = "";
        }, 5000);
      }

      showBooks() {
        let bookArray;
        let uiString = "";
        let bookList = localStorage.getItem("bookList");
        let display = document.getElementById("tableBody");
      
        if (bookList == null || bookList == "[]") {
          bookArray = [];
          display.innerHTML = `nothing to display, add books to display`;
        } else {
          bookArray = JSON.parse(bookList);
          bookArray.forEach((element, index) => {
            uiString += `<tr>
                  <th scope="row">${index + 1}</th>
                  <td>${element.name}</td>
                  <td>${element.author}</td>
                  <td>${element.type}</td>
                  <td><button type = "button" id = "removeBook"  onclick = removeBook(${index})>Delete</button></td>
                  </tr>`;
          });
          display.innerHTML = uiString;
        }
      }
}
  
  // onload of page display all the book list
  window.onload = new Display().showBooks();
  
  //Grab the inputs given by the user and store it into the local storgae
  
  let addBook = document.getElementById("addBook");
  
  addBook.addEventListener("submit", (e) => {
    let name = document.getElementById("bookName");
    let author = document.getElementById("author");
  
    let type;
  
    let fiction = document.getElementById("fiction");
    let programing = document.getElementById("programing");
    let cooking = document.getElementById("cooking");
  
    if (fiction.checked) {
      type = fiction.value;
    } else if (programing.checked) {
      type = programing.value;
    } else if (cooking.checked) {
      type = cooking.value;
    }
  
    let book = new Book(name.value, author.value, type);
    let displayBooks = new Display();
  
    if (book.name.length > 2 && book.author.length > 2 && book.type != null) {
      book.addToLocalStorage(book);
      displayBooks.showAlert("success", "Successfully added to localstorage");
      displayBooks.showBooks();
      book.clearFormFields();
    } else {
        console.log("came inside danger");
      new Display().showAlert("danger", "Could not process your request");
      book.clearFormFields();
      displayBooks.showBooks();
    }
    e.preventDefault();
  });
  
  
  // Remove a particular book from the list
  
  function removeBook(index) {
          
          
          let bookArray;
          let bookList = localStorage.getItem("bookList");
          bookArray = JSON.parse(bookList);
          bookArray.splice(index, 1);
          localStorage.setItem("bookList", JSON.stringify(bookArray));
          new Display().showBooks();
  }
  
  
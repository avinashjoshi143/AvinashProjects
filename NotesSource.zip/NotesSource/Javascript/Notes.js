let addNote = document.getElementById('Add');

window.onload = ShowNote();

//Add notes into local storage
addNote.addEventListener('click',(eventObject) => {  

    // get the values inputed in the textbox and textarea by using their id
    let noteTitle = document.getElementById('floatingPassword');
    let noteDescription = document.getElementById('floatingTextarea2');

    // get all the notes from local storage 
    let noteTitles = localStorage.getItem('NoteTitle');
    let noteDescriptions = localStorage.getItem('NoteDescription');

    let notesTitleArray;
    let notesDescriptionArray;
    
    // check if notes are null if  not parse them into javascript object i,e array
    if(noteTitles == null && noteDescriptions == null) {
        notesTitleArray = [];
        notesDescriptionArray = [];
    }
    else {
        notesTitleArray = JSON.parse(noteTitles);
        notesDescriptionArray = JSON.parse(noteDescriptions);
    }

    // Push the new inputed values into arrays
    notesTitleArray.push(noteTitle.value);
    notesDescriptionArray.push(noteDescription.value);


    //update the local storage 
    localStorage.setItem('NoteTitle',JSON.stringify(notesTitleArray));
    localStorage.setItem('NoteDescription', JSON.stringify(notesDescriptionArray));

    noteTitle.value = "";
    noteDescription.value = "";   
    ShowNote();
});

// Display notes list
function ShowNote(){
    
    // get all the notes from local storage 
    let noteTitles = localStorage.getItem('NoteTitle');
    let noteDescriptions = localStorage.getItem('NoteDescription');
    let notesTitleArray;
    let notesDescriptionArray;
    let html = "";
    
    // check if notes are null if  not parse them into javascript object i,e array
    if(noteTitles == null && noteDescriptions == null) {
        notesTitleArray = [];
        notesDescriptionArray = [];

    }
    else {
        notesTitleArray = JSON.parse(noteTitles);
        notesDescriptionArray = JSON.parse(noteDescriptions);
    }

    //iterate through each note item and put them into an html format 
    notesTitleArray.forEach((Title,titleIndex) => {
        notesDescriptionArray.forEach((Description,descriptionIndex) => {

            if (titleIndex == descriptionIndex) {

                html += `<div class="SearchCards card my-4 mx-4"  style="width: 18rem;">
    <div class="card-body">
      <h5 class="card-title search" >${Title}</h5>
      <p  class="card-text"> ${Description} </p>
      <button onclick = RemoveNote(${titleIndex},${descriptionIndex}) class="btn btn-primary">Delete</button>
    </div>
  </div>`;
                
            } else {
                
            }

        });
    });
    

    // displaying list of notes by checking the length of the arrays and also adding 
    let display = document.getElementById('display');
    if(notesTitleArray.length != 0 && notesDescriptionArray.length !=0){

        display.innerHTML = html;
    }
    else {
        display.innerHTML = '<P>Nothing to show please Add note to display </p>';
    }        
}

//Remove a particluar note and update local storage and display updated list of notes
function RemoveNote(titleIndex,descriptionIndex){

    // get all the notes from local storage 
    let noteTitles = localStorage.getItem('NoteTitle');
    let noteDescriptions = localStorage.getItem('NoteDescription');
    let notesTitleArray;
    let notesDescriptionArray;

    // check if notes are null if  not parse them into javascript object i,e array
    if(noteTitles == null && noteDescriptions == null) {
        notesTitleArray = [];
        notesDescriptionArray = [];
    }
    else {
        notesTitleArray = JSON.parse(noteTitles);
        notesDescriptionArray = JSON.parse(noteDescriptions);
    }


    // remove note from specified index 
    notesTitleArray.splice(titleIndex,1);
    notesDescriptionArray.splice(descriptionIndex,1);

    // update the local storage with new array by converting them into json string
    localStorage.setItem('NoteTitle',JSON.stringify(notesTitleArray));
    localStorage.setItem('NoteDescription', JSON.stringify(notesDescriptionArray));

    // display updated list of notes
    ShowNote();
}

//implementing search functionality

let search = document.getElementById('Search-Card');

search.addEventListener('input', () =>{
    let inputValue = search.value;
    let notesTitle = document.getElementsByClassName('SearchCards');

    Array.from(notesTitle).forEach(element => {

        let noteTxt = element.getElementsByClassName('search');
        noteTxt = noteTxt[0].innerText;
        if(noteTxt.toLowerCase().includes(inputValue.toLowerCase())){
            element.style.display = "block";
        }
        else {
            element.style.display = "none";
        }
    });
});


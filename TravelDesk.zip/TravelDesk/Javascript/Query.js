let isValidUname = false;
let isValidUemail = false;
let isValidUphone = false;
let isValidQuery = false;


let uName = document.getElementById('Name');
uName.addEventListener('blur', ()=> {
    let regex = /^[^\d\s\W][\w\.\-\s]{2,29}$/;

    if (regex.test(uName.value)) {
        uName.classList.add('is-valid');
        uName.classList.remove('is-invalid');
        isValidUname = true;
    } else {
        uName.classList.add('is-invalid');
        uName.classList.remove('is-valid');
        isValidUname = false;
    }
});

let uEmail = document.getElementById('Email');
uEmail.addEventListener('blur',()=> {
    let regex = /^[\w\.\-]+\@[\w\-\.]+\.[a-zA-Z]{2,7}$/;

    if (regex.test(uEmail.value)) {
        uEmail.classList.add('is-valid');
        uEmail.classList.remove('is-invalid');
        isValidUemail = true;
    } else {
        uEmail.classList.add('is-invalid');
        uEmail.classList.remove('is-valid');
        isValidUemail = false;
    }
});

let uPhone = document.getElementById('Phone');

uPhone.addEventListener('blur', ()=> {
    let regex = /^\d{10}$/;

    if (regex.test(uPhone.value)) {
        uPhone.classList.add('is-valid');
        uPhone.classList.remove('is-invalid');
        isValidUphone = true;
    } else {
        uPhone.classList.add('is-invalid');
        uPhone.classList.remove('is-valid');
        isValidUphone = false;
    }
});

let uQuery = document.getElementById('query');

uQuery.addEventListener('blur', ()=> {

    if (uQuery.value == "") {
        uQuery.classList.add('is-invalid')
        uQuery.classList.remove('is-valid');
        isValidQuery = false;
    } else {
        uQuery.classList.add('is-valid');
        uQuery.classList.remove('is-invalid');
        isValidQuery = true;
    }
});

let submit = document.getElementById('submit');

submit.addEventListener('submit', (e)=> {

    e.preventDefault();
    let status = document.getElementById('status');
    let uiString ="";
    if (isValidUname && isValidUemail && isValidUphone && isValidQuery) {

        
        uiString +=`<div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Success!</strong> Your query submited successfully.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>`;
        submit.reset();
        uName.classList.remove('is-valid');
        uEmail.classList.remove('is-valid');
        uPhone.classList.remove('is-valid');
        uQuery.classList.remove('is-valid');
    } else {
        uiString +=`<div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Error!</strong> Please fill all the fields properly.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>`;
    }
    status.innerHTML = uiString;
});
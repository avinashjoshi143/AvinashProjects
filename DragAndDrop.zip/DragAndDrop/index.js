let imgBox = document.querySelector('.imgBox');
let whiteBoxes = document.querySelectorAll('.whiteBox');

imgBox.addEventListener('dragstart',(e)=> {
    console.log("drag started");
    e.target.className += " hold"
    setTimeout(() => {
        e.target.className = "hide";
    }, 0);
});

imgBox.addEventListener('dragend',(e)=> {
    console.log("drag ended");
    e.target.className = "imgBox";
    
});

for (const whiteBox of whiteBoxes) {
    whiteBox.addEventListener('dragover',(e)=> {
        console.log("dragover started");
        e.preventDefault();
    });

    whiteBox.addEventListener('dragenter',(e)=> {
        console.log("dragenter started");
        e.target.className += " enter";

    });
    
    whiteBox.addEventListener('dragleave', (e)=> {
        console.log("dragleave started");
        e.target.className = "whiteBox";
    });

    whiteBox.addEventListener('drop',(e)=>{
        console.log("dragdrop started");
        e.target.append(imgBox);
    });
}
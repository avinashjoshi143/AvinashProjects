// Add Title and Desciption in local storgae called itemsjson
function addUpdate() {
  tit = document.getElementById("title").value;
  desc = document.getElementById("description").value;

  if (localStorage.getItem("itemsjson") == null) {
    itemjsonArray = [];
    itemjsonArray.push([tit, desc]);
    localStorage.setItem("itemsjson", JSON.stringify(itemjsonArray));
  } else {
    jsonArraystr = localStorage.getItem("itemsjson");
    itemjsonArray = JSON.parse(jsonArraystr);
    itemjsonArray.push([tit, desc]);
    localStorage.setItem("itemsjson", JSON.stringify(itemjsonArray));
  }
  document.getElementById('title').value = null;
  document.getElementById('description').value = null;
  displayItem(itemjsonArray);
}


//Populate Table in HTML

function displayItem(itemjsonArray) {
  let tblBody = document.getElementById("tableBody");
  let str = "";
  itemjsonArray.forEach((element, index) => {
    str += `
          <tr>
                <th scope="row">${index + 1}</th>
                <td>${element[0]}</td>
                <td>${element[1]}</td>
                <td><button class="btn btn-primary btn-sm" onclick = "_delete(${index})">Delete</button></td>
                </tr>`;
  });
  tblBody.innerHTML = str;
}

window.onload = function Starter(){
    itemjsonstr = localStorage.getItem('itemsjson');
    console.log(itemjsonstr);
    itemjsonArray = JSON.parse(itemjsonstr);
    console.log(itemjsonArray);
    displayItem(itemjsonArray);
}
add = document.getElementById("Add");
add.addEventListener("click", addUpdate);

// delete an element

function _delete(itemIndex) {
  //get items from local storage
  jsonArraystr = localStorage.getItem("itemsjson");
  itemjsonArray = JSON.parse(jsonArraystr);

  //deletes an item from array
  itemjsonArray = itemjsonArray.filter((element,index) => index != itemIndex)

  console.log(itemjsonArray);

  //set updates items in local storage
  localStorage.setItem("itemsjson", JSON.stringify(itemjsonArray));

  displayItem(itemjsonArray);
}

